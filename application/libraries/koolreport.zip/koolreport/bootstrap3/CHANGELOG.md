# Change Log

## Version 1.1.0

1. Fix the jquery path

## Version 1.0.0

1. First release
