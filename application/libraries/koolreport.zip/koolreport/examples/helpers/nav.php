<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
    <a id="baseUrl" class="navbar-brand" href="<?php echo $root_url; ?>">KoolReport Examples</a>
    <ul id="topMenu" class="navbar-nav mr-auto">

    </ul>
    <div class="my-2 my-lg-0">
        <a href="https://www.koolreport.com/get-koolreport-pro" class="btn-get-koolreort-pro btn btn-outline-success my-2 my-sm-0">Get KoolReport Pro</a>
    </div>
</nav>