# Change Log

## Version 1.2.0

1. BarCode: Use `onRender()` function instead of `render()`
2. QRCode: Use `onRender()` function instead of `render()`
3. Change qrcode library