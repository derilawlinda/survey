<?php
// DrillThrough is another name of MultiView widgets

namespace koolreport\drilldown;

class DrillThrough extends MultiView
{

}