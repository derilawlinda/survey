# Change Log

## Version 3.0.0

1. `DrillDown`: Fix widgets resize
1. `LegacyDrillDown`: Fix widgets resize
1. `CustomDrillDown`: Fix widgets resize
1. `MultiView`: Fix the multiview content size


## Version 2.5.0

1. Fix issue of DrillDown in Internet Explorer
2. Support bs4 theme for DrillDown, CustomDrillDown and MultiView
3. Change `DrillDown` to `LegacyDrillDown`
4. Create new `DrillDown`
5. Adding `content` property

## Version 2.0.0

1. DrillDown now is able to work with Table
2. DrillDown now is able to work with ChartJs

## Version 1.5.0

1. Change from using comment in HTML to using xml tag to mark drilldown partial.

## Version 1.0.0

1. Add DrillDown report
2. Add CustomDrillDown report
3. Add MultiView report
