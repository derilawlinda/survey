# Change Log

## Version 2.2.0

1. Change the chart to using new resource loading method.
2. Change default chart width to 100%    

## Version 2.0.0

1. Use Utility::jsonEncode() to enable js function definition in options.

## Version 1.8.0
1. Use the default `dataSource` from widget

## Version 1.2.0

1. Adding the "data" property to set data on the fly.
2. Fix the create() function