# Change Log

## Version 1.5.0

1. Upgrade to Bootstrap 4.3.1

## Version 1.1.0

1. Fix the jquery path

## Version 1.0.0

1. First release
