<?php

namespace koolreport\instant;

class ExporterTempReport extends \koolreport\KoolReport
{
    use \koolreport\export\Exportable;
}