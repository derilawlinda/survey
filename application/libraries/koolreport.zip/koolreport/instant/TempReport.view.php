<?php
$widgetClass = $this->params["@widgetClass"];
$widgetParams = $this->params["@widgetParams"];
$widgetClass::create($widgetParams);
?>