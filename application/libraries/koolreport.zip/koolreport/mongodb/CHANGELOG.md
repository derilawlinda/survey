# Change Log

## Version 1.2.0

1. Change data retrieval algorithm
2. Change mongodb/mongodb version

## Version 1.1.0

1. Change README

## Version 1.0.0

1. Create `\koolreport\mongo\MongoDataSource` to connect to MongoDB