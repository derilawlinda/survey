# Change Log

## Version 1.2.0

1. Change `process()` method name to `doProcess()` to avoid conflict with core Process class.

## Version 1.1.0

1. Change README

## Version 1.0.0

1. Create `Statistics` process
2. Create `StatisticReader`