var image_export = {
    os_name:"{os.name}",
    init:function(){
        
    }
}