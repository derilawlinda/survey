# Change Log

## Version 2.1.0
1. Add `plugins` to chart setting
2. Enhance the title options

## Version 2.0.0
1. Fix issue with "itemSelect" event

## Version 1.5.0

1. Change to new method resource loading method
2. Adding `ComboChart` class

## Version 1.2.0

1. Return data of selected row in form of associate array

## Version 1.1.0

1. Enable ability to write js anonymous function in options.
2. Display NoData when there is no data
3. Fix the issue with tooltips

## Version 1.0.0