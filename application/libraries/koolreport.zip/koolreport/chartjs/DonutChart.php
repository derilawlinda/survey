<?php
namespace koolreport\chartjs;
use \koolreport\core\Utility;

Class DonutChart extends PieChart
{
    protected $type = "doughnut";
}