<?php

namespace koolreport\chartjs;
use \koolreport\core\Utility;

class ComboChart extends BarChart
{
    protected $type="bar";
}