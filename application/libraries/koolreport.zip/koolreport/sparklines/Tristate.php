<?php

namespace koolreport\sparklines;

class Tristate extends Chart
{
    protected $type = "tristate";
}