# Change Log

## Version 1.5.0

1. Convert all charts to new loading methods
2. Fix the sparkline chart in bs4

## Version 1.2.0

1. Add ability to write js function definition in options.

## Version 1.1.0

1. Remove dataStore property and use the dataSource/dataSource of Widget
2. Auto select first column if `column` property is not set.