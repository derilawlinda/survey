<?php
/**
 * This file contains Bullet widget
 *
 * @author KoolPHP Inc (support@koolphp.net)
 * @link https://www.koolphp.net
 * @copyright KoolPHP Inc
 * @license https://www.koolreport.com/license
 */
namespace koolreport\sparklines;

class Bullet extends Chart
{
    protected $type = "bullet";
}