<?php
/**
 * This file contains Box widget
 *
 * @author KoolPHP Inc (support@koolphp.net)
 * @link https://www.koolphp.net
 * @copyright KoolPHP Inc
 * @license https://www.koolreport.com/license
 */
namespace koolreport\sparklines;

class Box extends Chart
{
    protected $type = "box";
}