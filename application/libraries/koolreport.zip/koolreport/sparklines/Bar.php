<?php
/**
 * This file contains Bar widget
 *
 * @author KoolPHP Inc (support@koolphp.net)
 * @link https://www.koolphp.net
 * @copyright KoolPHP Inc
 * @license https://www.koolreport.com/license
 */
namespace koolreport\sparklines;

class Bar extends Chart
{
    protected $type = "bar";
}